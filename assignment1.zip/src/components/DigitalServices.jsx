import React from "react";

const DigitalServices = () => {
  return (
    <>
      <section className="ourWorks py-10 sm:py-20 grid grid-cols-1 lg:grid-cols-2 gap-10 justify-center items-center">
        <div className="py-5 order-1 lg:order-none"> 
          <p className="text-2xl sm:text-3xl font-bold text-center lg:text-left">
            We Offer a Full Range of Digital Marketing Services!
          </p>
          <div className="text pt-4 text-center lg:text-left">
            <p>
              Lorem ipsum dolor sit amet, tincidunt vestibulum. Fusce egeabus
              consectetuer turpis, suspendisse.
            </p>
          </div>
          <div className="text pt-4 text-center lg:text-left">
            <p>
              Lorem ipsum dolor sit amet, tincidunt vestibulum. Fusce egeabus
              consectetuer turpis, suspendisse.
            </p>
          </div>
        </div>

        <div className="flex justify-center order-2 lg:order-none">
          <img src="https://themewagon.github.io/simple/images/Group1.png" alt="thumbnail" className="w-full max-w-sm"/>
        </div>

        <div className="flex justify-center order-4 lg:order-none">
          <img src="https://themewagon.github.io/simple/images/Group1.png" alt="thumbnail" className="w-full max-w-sm"/>
        </div>

        <div className="py-5 order-3 lg:order-none"> 
          <p className="text-2xl sm:text-3xl font-bold text-center lg:text-left">
            We Offer a Full Range of Digital Marketing Services!
          </p>
          <div className="text pt-4 text-center lg:text-left">
            <p>
              Lorem ipsum dolor sit amet, tincidunt vestibulum. Fusce egeabus
              consectetuer turpis, suspendisse.
            </p>
          </div>
          <div className="text pt-4 text-center lg:text-left">
            <p>
              Lorem ipsum dolor sit amet, tincidunt vestibulum. Fusce egeabus
              consectetuer turpis, suspendisse.
            </p>
          </div>
        </div>
      </section>
    </>
  );
};

export default DigitalServices;
